import React from 'react';
export const baseUrl = 'https://api.themoviedb.org/3';
export const API_KEY = '32bf8ea8471f676fd01a2e348190cf15';
export const imgUrl = 'https://image.tmdb.org/t/p/original';



