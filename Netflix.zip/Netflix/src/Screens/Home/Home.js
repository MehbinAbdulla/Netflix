import React from 'react';
import {API_KEY} from '../../Constants/constants.js';
import {baseUrl} from '../../Constants/constants.js';
import {imgUrl} from '../../Constants/constants.js';
import Navbar from '../../Components/Navbar/Navbar.js';
import Banner from '../../Components/Banner/Banner.js';
import Movierow from '../../Components/MovieRow/MovieRow.js';

function Home() {
  const genreUrl =baseUrl+"/genre/movie/list?api_key="+API_KEY+"&language=en-US";
  const [clickMovie,setClickMovie] = React.useState(0);
  const [genre,setGenre] = React.useState([]);
  React.useEffect(() => {
    apiGet();
  }, []);
  const apiGet =()=>{
    fetch(genreUrl)
      .then((response) => response.json())
      .then((data) => {
        setGenre(data.genres);
      });
  }
  
  return (
    <div>
      <Navbar/>
      <Banner/>
      {genre.map((obj)=>
      <Movierow genre={obj.id} genreName={obj.name}/>
      )}
    </div>
  );
}

export default Home;