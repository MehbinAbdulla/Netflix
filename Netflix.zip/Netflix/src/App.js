import React from 'react';
import './App.css';
import BottomNav from './Components/BottomNav/BottomNav.js';
import Home from './Screens/Home/Home.js';
function App() {
  return (
    <div className="App">
      <Home/>
      <BottomNav/>
    </div>
  );
}

export default App;
