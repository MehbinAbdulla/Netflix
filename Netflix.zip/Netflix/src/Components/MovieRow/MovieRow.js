import React from 'react';
import './MovieRow.css';
import {API_KEY} from '../../Constants/constants.js';
import {baseUrl} from '../../Constants/constants.js';
import {imgUrl} from '../../Constants/constants.js';

function Movierow(props) {
  const serverUrl = baseUrl+"/discover/movie?api_key="+API_KEY+"&language=en-US&with_genres="+props.genre;
  const [movie,setMovie] = React.useState([]);
  React.useEffect(() => {
      apiGet();
    }, []);
  //https://api.themoviedb.org/3/discover/movie?api_key=<<api_key>>&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page=1&with_genres=28&with_watch_monetization_types=flatrate

  const apiGet =()=>{
    fetch(serverUrl)
      .then((response) => response.json())
      .then((data) => {
        setMovie(data.results);
        });
  }

  return (
    <div className="row">
      <h2>{props.genreName}</h2>
      <div className="cardrow">
      {movie.map((obj)=>
        <div onClick={()=>Playscreen(obj.name||obj.title,obj.id)} style={{backgroundImage:`url(${imgUrl+obj.poster_path})`}} className="card">
          <div className="card-title">
            <h5>{obj.title||obj.name}</h5>
          </div>
        </div>
        //<img className="card" src={`${imgUrl+obj.poster_path}`}/>
      )}
      </div>
    </div>
      );
}
function Playscreen(name,id) {
    console.log(id+": "+name)
    alert(id+": "+name)
  }

export default Movierow;