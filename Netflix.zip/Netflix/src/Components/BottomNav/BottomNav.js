import React from 'react';
import './BottomNav.css';
function BottomNav() {
  return (
    <div className="BottomNav">
      <div className="grids active">
        <span className="material-icons-round white">home
        </span>
        Home
      </div>
      <div className="grids">
        <span className="material-icons-round white">search
        </span>
        Search
      </div>
      <div className="grids">
        <span className="material-icons-round white">smart_display
        </span>
        Coming Soon
      </div>
      <div className="grids">
        <span className="material-icons-round white">download
        </span>
        Download
      </div>
      <div className="grids">
        <span className="material-icons-round white">more_vert
        </span>
        More
      </div>
    </div>
    )
}
export default BottomNav;