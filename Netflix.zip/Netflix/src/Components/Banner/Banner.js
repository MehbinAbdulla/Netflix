import React from 'react';
import {API_KEY} from '../../Constants/constants.js';
import {baseUrl} from '../../Constants/constants.js';
import {imgUrl} from '../../Constants/constants.js';
import './Banner.css';
function Banner() {
  const serverUrl = baseUrl+"/trending/all/week?api_key="+API_KEY+"&language=en-US";
  const [movie,setMovie] = React.useState();
  React.useEffect(() => {
    apiGet();
  }, []);
  const apiGet =()=>{
    fetch(serverUrl)
      .then((response) => response.json())
      .then((data) => {
        setMovie(data.results[0]);
        });
  }
  return (
    <div style={{backgroundImage:`url(${movie ? imgUrl+movie.backdrop_path : "" })`}} className="banner">
      <div className="content">
        <h1 className="title">{movie ? movie.title||movie.name : ""}</h1>
        <div className="banner-buttons">
          <button className="button play-white">▶ Play</button>
          <button className="button">✚ My List</button>
        </div>
        <h3 className="subtitle">IMDB Rating: {movie ? movie.vote_average : ""}/10</h3>
        <p className="description">{movie ? movie.overview : ""}</p>
      </div>
    </div>
    )
}
export default Banner;