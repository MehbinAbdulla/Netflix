import React from 'react';
import './Navbar.css';
function Navbar() {
  return (
    <div>
      <div className="Navbar">
        <img className="logo" src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Netflix_2015_logo.svg/340px-Netflix_2015_logo.svg.png" alt="Netflix"/>
        <div className="right">
          <p className="material-icons-round white">cast</p>
          <p className="material-icons-round white">account_circle</p>
        </div>
      </div>
      
    </div>
    )
}
export default Navbar;